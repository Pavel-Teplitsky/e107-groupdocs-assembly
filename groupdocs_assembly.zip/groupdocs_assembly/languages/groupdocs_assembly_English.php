<?php
define("GDASSLAN_01", "Lets you embed Assemblyes from your GroupDocs acount in a web page using the GroupDocs Assembly (no Flash or PDF browser plug-ins required).");
define("GDASSLAN_02", "Settings");
define("GDASSLAN_03", "Installation Successful...");
define("GDASSLAN_04", "Upgrade successful...");
define("GDASSLAN_05", "Save Changes");
define("GDASSLAN_06", "Changes were saved successfully.");
define("GDASSLAN_07", "Error: please fill all inputs!");
?>